<?php

require 'bootstrap.php';

$calculator = new \Application\Cli\Calculator();
$calculator->run();